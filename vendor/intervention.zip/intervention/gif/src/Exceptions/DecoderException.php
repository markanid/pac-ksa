<?php

declare(strict_types=1);

namespace Intervention\Gif\Exceptions;

class DecoderException extends \RuntimeException
{
}
