<?php

declare(strict_types=1);

namespace Intervention\Gif;

abstract class AbstractExtension extends AbstractEntity
{
    public const MARKER = "\x21";
}
