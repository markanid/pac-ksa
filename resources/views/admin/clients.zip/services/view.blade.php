@extends('admin.layout')

@section('content-header')
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0"></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{route('dashboard')}}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{route('services.index')}}">{{$page}}</a></li>
                    <li class="breadcrumb-item active">{{$title}}</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@endsection

@section('body')
<div class="card card-primary card-outline">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title"><i class="fas fa-users"></i> View {{$page}}</h3>  
        <div class="ml-auto"> 
            <a href="{{ route('services.create') }}" class="btn btn-sm btn-primary"> <i class="fas fa-plus-circle"></i> Create</a> &nbsp;
            <a href="{{ route('services.edit', ['id' => $service->id]) }}" class="btn btn-sm btn-info"> <i class="fas fa-pencil-alt"></i> Edit</a> &nbsp;
            <a href="{{ route('services.index') }}" class="btn btn-sm btn-dark"> <i class="fa fa-arrow-circle-left"></i> Back</a> &nbsp;
        </div> 
    </div>
    <div class="card-body">
        
        <div class="table-responsive">
            <table class="table table-bordered" style="margin-bottom: 10px;">
                <tbody>
                    <tr>
                        <td style="background-color:#096ca5; color:#fff;">Service Name</td>
                        <td><b style="color:#096ca5;">{{ $service->name }}</b></td>
                        <td style="background-color:#096ca5; color:#fff;">Service Name [Arabic]</td>
                        <td><b style="color:#096ca5;">{{ $service->name_ar }}</b></td>
                    </tr>
                </tbody>
            </table>
       </div>
        <div class="table-responsive">
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <td rowspan="3">
                            <div>
                                @if(!empty($service) && !empty($service->image))
                                    <p><img src="{{asset('storage/services/'.$service->image)}}" alt="{{ $service->image_alt_tag }}" style="width: 150px; height: 150px;"></p>
                                @else
                                    <p><img src="{{asset('uploads/employees/avatar.png')}}" alt="{{ $service->image_alt_tag }}" style="width: 150px; height: 150px;"></p>
                                @endif 
                            </div>
                        </td>
                        <td colspan="2">
                            <span>Details :</span>
                            <label>{!! $service->details !!}</label>
                        </td>
                        <td colspan="2">
                            <span>Details [Arabic] :</span>
                            <label>{!! $service->details_ar !!}</label>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <span>Meta Title :</span>
                            <label>{{ $service->meta_title }}</label>
                        </td>
                        <td>
                            <span>Meta Description :</span>
                            <label>{{ $service->description }}</label>
                        </td>
                        <td>
                            <span>Keywords :</span>
                            <label>{{ $service->keyword }}</label>
                        </td>
                        <td>
                            <span>Image Alt-Tag :</span>
                            <label>{{ $service->image_alt_tag }}</label>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
       
    </div>
   
</div>
@endsection

@section('scripts')
<script>
    $(document).ready(function(){
        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
        
        // Check for the flash message and display the SweetAlert2 popup
        @if(session('success'))
            Toast.fire({
                icon: 'success',
                title: '{{ session('success') }}'
            });
        @endif
        @if(session('info'))
            Toast.fire({
                icon: 'info',
                title: '{{ session('info') }}'
            });
        @endif
    });
</script>
@endsection